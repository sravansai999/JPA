package com.cg;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class NamedQuery {

	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		
		TypedQuery<Employee>query=em.createNamedQuery("getEmployeeByGender",Employee.class);
		query.setParameter("gen", "Male");
		List<Employee>employees=query.getResultList();
		for (Employee employee : employees) {
			System.out.println(employee);
		}

	}

}
