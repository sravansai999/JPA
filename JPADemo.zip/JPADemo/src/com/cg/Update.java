package com.cg;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Update {
	public static void main(String[] args) {
	
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=fac.createEntityManager();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter EmployeeId");
	int empId=sc.nextInt();
	System.out.println("Enter Age");
	int age=sc.nextInt();
	System.out.println("Enter Salary");
	double salary=sc.nextDouble();
	
	Query query =em.createQuery("delete from Employee where salary>:sal");
	query.setParameter("age",age);
	query.setParameter("sal",salary);
	query.setParameter("eno",empId);
	em.getTransaction().begin();
	int result=query.executeUpdate();
	em.getTransaction().commit();
	System.out.println(result+" row(s) update");

}
}
