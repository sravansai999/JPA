package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Mainapp{

	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		
		User user=new User();
		user.setName("Anil");
		
		Vehicle vehicle=new Vehicle();
		vehicle.setVehicleName("car");
		user.setVehicle(vehicle);
		vehicle.setUser(user);
		em.getTransaction().begin();
		
		//em.persist(vehicle);
		em.persist(user);
		em.getTransaction().commit();

	}

}
