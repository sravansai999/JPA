package com.cg.association.topic;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)//by default it is single table like all will be in one table
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)//it will be divided individual table like vehicle twowheeler fourwheeler
@Inheritance(strategy = InheritanceType.JOINED) // common data will be shown between them
@DiscriminatorValue("GV")
public class Vehicles {

	@Id
	@GeneratedValue
	private int vehicleId;
	private String vehicleName;
	private String licenseNumber;

	public Vehicles() {
		super();
	}

	public Vehicles(int vehicleId, String vehicleName, String licenseNumber) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleName = vehicleName;
		this.licenseNumber = licenseNumber;
	}

	@Override
	public String toString() {
		return "Vehicles [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName + ", licenseNumber=" + licenseNumber
				+ "]";
	}

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

}