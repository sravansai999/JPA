package com.cg.association.topic;

import javax.persistence.Entity;

@Entity
public class TwoWheeler extends Vehicles {

	private String steeringHandle;

	public String getSteeringHandle() {
		return steeringHandle;
	}

	public void setSteeringHandle(String steeringHandle) {
		this.steeringHandle = steeringHandle;
	}

}
