package com.cg;


import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;



public class JpaQueryDemo {

	public static void main(String[] args) {
		
		
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter empId");
		int empId=sc.nextInt();
		//for only one result
		TypedQuery<Employee> query=em.createQuery("from Employee where id=:eno",
				  Employee.class);
		query.setParameter("eno", empId);
		Employee employee=query.getSingleResult();
		System.out.println(employee);
		/*
		 * //TypedQuery<Employee> query=em.createQuery("select emp from Employee emp",
		 * Employee.class);//typed query is used when u know the data what is coming
		 * TypedQuery<Employee> query=em.createQuery("from Employee where id=:eno",
		 * Employee.class); //TypedQuery<Employee>
		 * query=em.createQuery("select emp from Employee emp where emp.gender=:gen",
		 * Employee.class);//other form of above line query.setParameter("eno", empId);
		 * List<Employee>employees=query.getResultList(); for (Employee employee :
		 * employees) { System.out.println(employee); }
		 */
		//for multiple result
	}
	
}

